#ifdef _MSC_VER

#pragma warning(disable: 4074)
#pragma init_seg(compiler)

#endif

typedef signed char        int8;
typedef unsigned char      uint8;
typedef short int          int16;
typedef short unsigned     uint16;
typedef int                int32;
typedef unsigned int       uint32;
typedef long long          int64;
typedef unsigned long long uint64;
typedef long double        float80;
typedef long double        float80;
typedef uint32             size_t;

extern size_t Z2_STDLIB_GC;

extern "C" __declspec(dllimport) int32 __stdcall MessageBoxW(uint32 hWnd, uint16* lpText, uint16* lpCaption, uint32 uType);
extern "C" __declspec(dllimport) uint32 __stdcall GetStdHandle(uint32 nStdHandle);
extern "C" __declspec(dllimport) int32 __stdcall WriteFile(uint32 hFile, uint8* Buffer, uint32 nNumberOfBytesToWrite, uint32* lpNumberOfBytesWritten, uint8* lpOverlapped);

class LeakTest {
public:
	~LeakTest() {
		if (Z2_STDLIB_GC) {
			//MessageBoxW(0, (uint16*)L"Memory leaks detected!", (uint16*)L"Error!", 0x00000010);
			uint32 dummy;
			uint32 handle = ::GetStdHandle(4294967285u);
			::WriteFile(handle, (uint8*)"Memory leaks detected!\n", 23, &dummy, 0);
		}
	}
};

#ifdef _MSC_VER
static LeakTest leakTest;
#else
static LeakTest leakTest __attribute__ ((init_priority (1)));

#include "cpuid.h"

inline int cpuid(int reg[4], int level) {
	__get_cpuid(level, (uint32*)&reg[0], (uint32*)&reg[1], (uint32*)&reg[2], (uint32*)&reg[3]);
}

#undef __cpuid

extern "C" void __cpuid(int reg[4], int level) {
	int result = cpuid(reg, level);
}


#endif