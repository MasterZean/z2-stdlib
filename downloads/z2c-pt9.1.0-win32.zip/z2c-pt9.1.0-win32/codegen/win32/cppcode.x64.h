typedef signed char        int8;
typedef unsigned char      uint8;
typedef short int          int16;
typedef short unsigned     uint16;
typedef int                int32;
typedef unsigned int       uint32;
typedef long long          int64;
typedef unsigned long long uint64;
typedef long double        float80;
typedef long double        float80;
typedef uint64             size_t;

extern "C" {
	void* __cdecl memcpy(void * _Dst, const void * _Src, size_t _Size);
	void* __cdecl memset(void*  _Dst, int _Val, size_t _Size);
	size_t __cdecl strlen(const char * _Str);
	double __cdecl fmod(double x, double y);
	double __cdecl sqrt(double x);
	double __cdecl log(double x);
	double __cdecl log10(double y);
	double __cdecl pow(double x, double y);
	void * __cdecl malloc(size_t _Size);
	void   __cdecl free(void * _Memory);
	int atexit(void (*function)(void));
		
	void __cpuid(int[4], int);
}

inline void* operator new(size_t, void* here) {
	return here;
}
    
inline void operator delete(void*, void*) {
}

size_t Z2_STDLIB_GC;

inline uint8* zl_clone(void* p, size_t size) {
	if (size == 0)
		return 0;
	uint8* b = (uint8*)malloc(size);
	Z2_STDLIB_GC++;
	if (p)
		memcpy(b, p, size);
	return b;
}

inline uint8* zl_clone(void* p, size_t size, size_t rdlim) {
	if (size == 0)
		return 0;
	uint8* b = (uint8*)malloc(size);
	Z2_STDLIB_GC++;
	if (p)
		memcpy(b, p, rdlim < size ? rdlim : size);
	return b;
}

inline void zl_free(void** p) {
	if (*p) {
		Z2_STDLIB_GC--;
		free(*p);
	}
	*p = 0;
}

inline float bitnot(float f) {
	int32* p = (int32*)&f;
	*p = ~*p;
	return *(float*)p;
}

inline double bitnot(double f) {
	int64* p = (int64*)&f;
	*p = ~*p;
	return *(double*)p;
}

