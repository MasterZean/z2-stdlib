extern "C" {
	uint8 _rotr8(uint8 value, uint8 shift);
	uint16 _rotr16(uint16 value, uint8 shift);
	uint8 _rotl8(uint8 value, uint8 shift);
	uint16 _rotl16(uint16 value, uint8 shift);
	uint32 __cdecl _rotl(uint32 _Val, int32 _Shift);
	uint64 __cdecl _rotl64(uint64 _Val, int32 _Shift);
	uint32 __cdecl _rotr(uint32 _Val, int32 _Shift);
	uint64 __cdecl _rotr64(uint64 _Val, int32 _Shift);
}

#pragma intrinsic(_rotl)
#pragma intrinsic(_rotl64)
#pragma intrinsic(_rotr)
#pragma intrinsic(_rotr64)

