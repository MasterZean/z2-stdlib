inline uint8 _rotl8(uint8 x, uint8 r) {
  return (x << r) | (x >> (8 - r));
}

inline uint8 _rotr8(uint8 x, uint8 r) {
  return (x >> r) | (x << (8 - r));
}

inline uint16 _rotl16(uint16 x, uint8 r) {
  return (x << r) | (x >> (16 - r));
}

inline uint16 _rotr16(uint16 x, uint8 r) {
  return (x >> r) | (x << (16 - r));
}

inline uint32 _rotl(uint32 x, uint8 r) {
  return (x << r) | (x >> (32 - r));
}

inline uint32 _rotr(uint32 x, uint8 r) {
  return (x >> r) | (x << (32 - r));
}

inline uint64 _rotl64 (uint64 x, int8 r)
{
  return (x << r) | (x >> (64 - r));
}

inline uint64 _rotr64 (uint64 x, int8 r)
{
  return (x >> r) | (x << (64 - r));
}

