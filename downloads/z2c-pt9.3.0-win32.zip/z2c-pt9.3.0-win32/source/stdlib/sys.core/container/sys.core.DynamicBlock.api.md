sys.core.DynamicBlock this
=
## Brief

### param a

### param copy

***

sys.core.DynamicBlock @allocate
=
## Brief

### param len

### param capacity

***

sys.core.DynamicBlock @attr
=
## Brief

### param copy

***

sys.core.DynamicBlock ExpandTo
=
## Brief

### param value

### param newLength

### param init

***

sys.core.DynamicBlock ExpandBy
=
## Brief

### param delta

### param init

***

sys.core.DynamicBlock ShrinkTo
=
## Brief

### param newLength

***

sys.core.DynamicBlock ShrinkBy
=
## Brief

### param delta

***

sys.core.DynamicBlock Fill
=
## Brief

### param value

***

sys.core.DynamicBlock Clear
=
## Brief

***

sys.core.DynamicBlock Append
=
## Brief

### param item

### param count

***

sys.core.DynamicBlock SetLengthUnsafe
=
## Brief

### param value

***

sys.core.DynamicBlock ExpandUnsafe
=
## Brief

### param value

***

sys.core.DynamicBlock ShrinkUnsafe
=
## Brief

### param value

***

sys.core.DynamicBlock FreeUnsafe
=
## Brief

### param len

***

sys.core.DynamicBlock @index
=
## Brief

***

sys.core.DynamicBlock Length
=
## Brief

***

sys.core.DynamicBlock IsEmpty
=
## Brief

***

sys.core.DynamicBlock Capacity
=
## Brief

***

sys.core.DynamicBlock SysDataPointer
=
## Brief

***

