sys.core.lang.CArray this
=
## Brief

### param item

***

sys.core.lang.CArray Fill
=
## Brief

### param value

***

sys.core.lang.CArray Insert
=
## Brief

### param pos

### param item

***

sys.core.lang.CArray Delete
=
## Brief

### param pos

***

sys.core.lang.CArray FindIndex
=
## Brief

### param item

### param start

### returns

***

sys.core.lang.CArray BinaryIndex
=
## Brief

### param item

### returns

***

sys.core.lang.CArray Reverse
=
## Brief

### param start

### param end

***

sys.core.lang.CArray Sum
=
## Brief

### returns

***

sys.core.lang.CArray Sort
=
## Brief

### param low

### param high

***

sys.core.lang.CArray SortDescending
=
## Brief

### param low

### param high

***

sys.core.lang.CArray @write
=
## Brief

### param stream

***

sys.core.lang.CArray IsEmpty
=
## Brief

***

