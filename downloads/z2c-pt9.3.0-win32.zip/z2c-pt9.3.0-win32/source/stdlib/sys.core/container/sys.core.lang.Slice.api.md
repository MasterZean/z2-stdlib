sys.core.lang.Slice this
=
## Brief

### param ppp

### param p

### param length

### param start

### param end

### param offset

***

sys.core.lang.Slice Fill
=
## Brief

### param value

### param items

***

sys.core.lang.Slice FindIndex
=
## Brief

### param item

### param start

### param b

### returns

***

sys.core.lang.Slice RFindIndex
=
## Brief

### param item

### param start

### param b

### returns

***

sys.core.lang.Slice BinaryIndex
=
## Brief

### param item

### returns

***

sys.core.lang.Slice Reverse
=
## Brief

***

sys.core.lang.Slice Delete
=
## Brief

### param item

### param items

### returns

***

sys.core.lang.Slice DeleteAll
=
## Brief

### param item

### param items

### returns

***

sys.core.lang.Slice DeleteIndex
=
## Brief

### param index

### param items

### returns

***

sys.core.lang.Slice Insert
=
## Brief

### param pos

### param item

### param items

***

sys.core.lang.Slice Sort
=
## Brief

### param low

### param high

***

sys.core.lang.Slice SortDec
=
## Brief

### param low

### param high

***

sys.core.lang.Slice Sum
=
## Brief

### returns

***

sys.core.lang.Slice Length
=
## Brief

***

sys.core.lang.Slice @index
=
## Brief

***

sys.core.lang.Slice SysDataPointer
=
## Brief

***

