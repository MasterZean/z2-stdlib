sys.core.lang.Vector this
=
## Brief

### param copy

***

sys.core.lang.Vector @attr
=
## Brief

### param copy

***

sys.core.lang.Vector Add
=
## Brief

### param item

### param items

***

sys.core.lang.Vector @shl
=
## Brief

***

sys.core.lang.Vector Fill
=
## Brief

### param value

### param items

***

sys.core.lang.Vector FindIndex
=
## Brief

### param item

### param start

### returns

***

sys.core.lang.Vector BinaryIndex
=
## Brief

### param item

### returns

***

sys.core.lang.Vector Reverse
=
## Brief

### param start

### param end

***

sys.core.lang.Vector Delete
=
## Brief

### param item

### param items

### returns

***

sys.core.lang.Vector DeleteAll
=
## Brief

### param item

### returns

***

sys.core.lang.Vector DeleteIndex
=
## Brief

### param item

### param items

### returns

***

sys.core.lang.Vector Insert
=
## Brief

### param pos

### param item

### param items

***

sys.core.lang.Vector Sum
=
## Brief

### returns

***

sys.core.lang.Vector Sort
=
## Brief

### param low

### param high

***

sys.core.lang.Vector SortDec
=
## Brief

### param low

### param high

***

sys.core.lang.Vector @write
=
## Brief

### param stream

***

sys.core.lang.Vector Length
=
## Brief

***

sys.core.lang.Vector Capacity
=
## Brief

***

sys.core.lang.Vector @index
=
## Brief

***

sys.core.lang.Vector At
=
## Brief

***

sys.core.lang.Vector SysDataPointer
=
## Brief

***

