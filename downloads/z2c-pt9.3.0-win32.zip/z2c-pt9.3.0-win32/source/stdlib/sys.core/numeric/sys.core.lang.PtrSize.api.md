sys.core.lang.PtrSize Clamp
=
## Brief

### param min

### param max

***

sys.core.lang.PtrSize Clamped
=
## Brief

### param min

### param max

### returns

***

sys.core.lang.PtrSize @write
=
## Brief

### param stream

### param format

***

sys.core.lang.PtrSize @put
=
## Brief

### param stream

***

sys.core.lang.PtrSize @get
=
## Brief

### param stream

***

sys.core.lang.PtrSize Abs
=
## Brief

***

sys.core.lang.PtrSize Sqr
=
## Brief

***

sys.core.lang.PtrSize Sqrt
=
## Brief

***

sys.core.lang.PtrSize Floor
=
## Brief

***

sys.core.lang.PtrSize Ceil
=
## Brief

***

sys.core.lang.PtrSize Round
=
## Brief

***

sys.core.lang.PtrSize Zero
=
## Brief

***

sys.core.lang.PtrSize One
=
## Brief

***

sys.core.lang.PtrSize Min
=
## Brief

***

sys.core.lang.PtrSize Max
=
## Brief

***

sys.core.lang.PtrSize Invalid
=
## Brief

***

sys.core.lang.PtrSize IsSigned
=
## Brief

***

sys.core.lang.PtrSize IsInteger
=
## Brief

***

sys.core.lang.PtrSize MaxDigitsLow
=
## Brief

***

sys.core.lang.PtrSize MaxDigitsHigh
=
## Brief

***

