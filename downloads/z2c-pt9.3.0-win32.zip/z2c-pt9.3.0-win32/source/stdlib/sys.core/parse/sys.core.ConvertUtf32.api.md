sys.core.ConvertUtf32 FromUtf8
=
## Brief
Converts a source Utf8 buffer to a destination Utf32 buffer.

### param dest
the destination buffer
### param src
the source buffer
***

