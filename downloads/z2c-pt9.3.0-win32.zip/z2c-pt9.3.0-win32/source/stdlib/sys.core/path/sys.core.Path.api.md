sys.core.Path GetFolder
=
## Brief

### param path

### returns

***

sys.core.Path GetFolderNoSep
=
## Brief

### param path

### returns

***

sys.core.Path GetName
=
## Brief

### param path

### returns

***

sys.core.Path GetNameIndex
=
## Brief

### param path

### returns

***

sys.core.Path GetTitle
=
## Brief

### param path

### returns

***

sys.core.Path GetTitleIndex
=
## Brief

### param path

### returns

***

sys.core.Path GetExtension
=
## Brief

### param path

### returns

***

sys.core.Path GetExtensionIndex
=
## Brief

### param path

### returns

***

sys.core.Path GetParent
=
## Brief

### param path

### returns

***

sys.core.Path IsRoot
=
## Brief

### param path

### returns

***

sys.core.Path CurrentFolder
=
## Brief

***

sys.core.Path ExeFileName
=
## Brief

***

sys.core.Path DirSep
=
## Brief

***

sys.core.Path IgnoreCase
=
## Brief

***

sys.core.Path DirSepWin
=
## Brief

***

sys.core.Path DirSepUnix
=
## Brief

***

