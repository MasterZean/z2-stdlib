sys.core.lang.String this
=
## Brief

### param chars

### param len

### param cap

### param obj

***

sys.core.lang.String FromIndex
=
## Brief

### param chars

### param start

### param end

***

sys.core.lang.String TakeOwnership
=
## Brief

### param chars

### param len

***

sys.core.lang.String @attr
=
## Brief

### param obj

***

sys.core.lang.String Clear
=
## Brief

***

sys.core.lang.String @eq
=
## Brief

### param second

### returns

***

sys.core.lang.String @neq
=
## Brief

### param second

### returns

***

sys.core.lang.String @shl
=
## Brief

### param ch

### param str

### returns

***

sys.core.lang.String Insert
=
## Brief

### param pos

### param string

***

sys.core.lang.String Inserted
=
## Brief

### param pos

### param string

### returns

***

sys.core.lang.String Find
=
## Brief

### param b

### param start

### returns

***

sys.core.lang.String RFind
=
## Brief

### param b

### param start

### returns

***

sys.core.lang.String Parse
=
## Brief

***

sys.core.lang.String ParseSaturated
=
## Brief

***

sys.core.lang.String Split
=
## Brief

### param b

### returns

***

sys.core.lang.String @write
=
## Brief

### param stream

### param format

***

sys.core.lang.String @put
=
## Brief

### param stream

***

sys.core.lang.String @get
=
## Brief

### param stream

***

sys.core.lang.String Length
=
## Brief

***

sys.core.lang.String Capacity
=
## Brief

***

sys.core.lang.String @index
=
## Brief

***

sys.core.lang.String IsEmpty
=
## Brief

***

sys.core.lang.String SysDataPointer
=
## Brief

***

sys.core.lang.String GrowthSpacing
=
## Brief

***

