sys.core.Class @write
=
## Brief
Writes the name of the class to an output stream.

### param stream
the output stream
***

sys.core.Class Name
=
## Brief
Returns the fully qualified class name.

***

sys.core.Class ShortName
=
## Brief
Returns only the class name, without the namespace.

***

sys.core.Class Namespace
=
## Brief
Returns the namespace of the class.

***

