sys.core.Thread Sleep
=
## Brief
Puts the main thread of application to sleep for an input amount of milliseconds.

### param msec
number of milliseconds to sleep
***

