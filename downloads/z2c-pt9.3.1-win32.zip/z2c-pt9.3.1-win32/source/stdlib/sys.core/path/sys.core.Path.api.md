Methods
---

#### GetFolder

```C#
static def GetFolder(path: String)
```

##### Brief

###### param path

###### returns

***

#### GetFolderNoSep

```C#
static def GetFolderNoSep(path: String)
```

##### Brief

###### param path

###### returns

***

#### GetName

```C#
static def GetName(path: String)
```

##### Brief

###### param path

###### returns

***

#### GetNameIndex

```C#
static def GetNameIndex(path: String)
```

##### Brief

###### param path

###### returns

***

#### GetTitle

```C#
static def GetTitle(path: String)
```

##### Brief

###### param path

###### returns

***

#### GetTitleIndex

```C#
static def GetTitleIndex(path: String)
```

##### Brief

###### param path

###### returns

***

#### GetExtension

```C#
static def GetExtension(path: String)
```

##### Brief

###### param path

###### returns

***

#### GetExtensionIndex

```C#
static def GetExtensionIndex(path: String)
```

##### Brief

###### param path

###### returns

***

#### GetParent

```C#
static def GetParent(path: String)
```

##### Brief

###### param path

###### returns

***

#### IsRoot

```C#
static def IsRoot(path: String)
```

##### Brief

###### param path

###### returns

***

Properties
---

#### CurrentFolder

```C#
property CurrentFolder: String
```

##### Brief

***

#### ExeFileName

```C#
property ExeFileName: String; get;
```

##### Brief

***

Constants
---

#### DirSep

```C#
const DirSep
```

##### Brief

***

#### IgnoreCase

```C#
const IgnoreCase
```

##### Brief

***

#### DirSepWin

```C#
const DirSepWin
```

##### Brief

***

#### DirSepUnix

```C#
const DirSepUnix
```

##### Brief

***

