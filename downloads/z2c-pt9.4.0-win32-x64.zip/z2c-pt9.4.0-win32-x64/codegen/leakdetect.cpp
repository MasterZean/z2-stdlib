#ifdef _MSC_VER

#pragma warning(disable: 4074)
#pragma init_seg(compiler)

#endif

typedef signed char        int8;
typedef unsigned char      uint8;
typedef short int          int16;
typedef short unsigned     uint16;
typedef int                int32;
typedef unsigned int       uint32;
typedef long long          int64;
typedef unsigned long long uint64;

#if _MSC_VER
	#if _WIN64
		#define __Z_64COMP
	#else
		#define __Z_32COMP
	#endif
	
	#define __CDECL __cdecl
#endif

#if __GNUC__
	#if __x86_64__ || __ppc64__
		#define __Z_64COMP
	#else
		#define __Z_32COMP
	#endif

	#define __CDECL
#endif

#if defined(__Z_32COMP)
typedef uint32             size_t;
const size_t __Z_MEMBER_OFFSET = 4;
#endif

#if defined(__Z_64COMP)
typedef uint64             size_t;
const size_t __Z_MEMBER_OFFSET = 8;
#endif

extern size_t Z2_STDLIB_GC;

#ifdef _MSC_VER
extern "C" __declspec(dllimport) int32 __stdcall MessageBoxW(uint32 hWnd, uint16* lpText, uint16* lpCaption, uint32 uType);
extern "C" __declspec(dllimport) uint32 __stdcall GetStdHandle(uint32 nStdHandle);
extern "C" __declspec(dllimport) int32 __stdcall WriteFile(uint32 hFile, uint8* Buffer, uint32 nNumberOfBytesToWrite, uint32* lpNumberOfBytesWritten, uint8* lpOverlapped);
#endif

class LeakTest {
public:
	~LeakTest() {
		if (Z2_STDLIB_GC) {
			//MessageBoxW(0, (uint16*)L"Memory leaks detected!", (uint16*)L"Error!", 0x00000010);
#ifdef _MSC_VER
			uint32 dummy;
			uint32 handle = ::GetStdHandle(4294967285u);
			::WriteFile(handle, (uint8*)"Memory leaks detected!\n", 23, &dummy, 0);
#endif
		}
	}
};

#ifdef _MSC_VER

static LeakTest leakTest;

extern "C" void __cpuid(int reg[4], int level);

extern "C" void cpuid(int reg[4], int level) {
	__cpuid(reg, level);
}

#endif

#ifdef __GNUC__

static LeakTest leakTest __attribute__ ((init_priority (1000)));

#if __unix || __unix__ || __APPLE__ || _linux

extern "C" int __get_cpuid (unsigned int __level,
    unsigned int *__eax, unsigned int *__ebx,
    unsigned int *__ecx, unsigned int *__edx);
    
extern "C" void cpuid(int reg[4], int level) {
	__get_cpuid(level, (uint32*)&reg[0], (uint32*)&reg[1], (uint32*)&reg[2], (uint32*)&reg[3]);
}

#else

extern "C" void __cpuid(int reg[4], int level);

extern "C" void cpuid(int reg[4], int level) {
	__cpuid(reg, level);
}

#endif

#endif
