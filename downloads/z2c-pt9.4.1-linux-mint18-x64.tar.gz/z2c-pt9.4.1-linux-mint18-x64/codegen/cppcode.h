typedef signed char        int8;
typedef unsigned char      uint8;
typedef short int          int16;
typedef short unsigned     uint16;
typedef int                int32;
typedef unsigned int       uint32;
typedef long long          int64;
typedef unsigned long long uint64;

#if _MSC_VER
	#if _WIN64
		#define __Z_64COMP
	#else
		#define __Z_32COMP
	#endif
	
	#define __CDECL __cdecl
#endif

#if __GNUC__
	#if __x86_64__ || __ppc64__
		#define __Z_64COMP
	#else
		#define __Z_32COMP
	#endif

	#define __CDECL
#endif

#if defined(__Z_32COMP)
typedef uint32             size_t;
const size_t __Z_MEMBER_OFFSET = 4;
#endif

#if defined(__Z_64COMP)
typedef uint64             size_t;
const size_t __Z_MEMBER_OFFSET = 8;
#endif

extern "C" {
	void* __CDECL memcpy(void* _Dst, const void* _Src, size_t _Size);
	void* __CDECL memset(void*  _Dst, int _Val, size_t _Size);
	void* __CDECL realloc(void*  _Block, size_t _Size);
	double __CDECL fmod(double x, double y);
	void * __CDECL malloc(size_t _Size);
	void   __CDECL free(void * _Memory);
}

inline void* operator new(size_t, void* here) {
	return here;
}
    
inline void operator delete(void*, void*) {
}

size_t Z2_STDLIB_GC;

inline uint8* zl_clone(void* p, size_t size) {
	if (size == 0)
		return 0;
	uint8* b = (uint8*)malloc(size);
	Z2_STDLIB_GC++;
	if (p)
		memcpy(b, p, size);
	return b;
}

inline uint8* zl_clone(void* p, size_t size, size_t rdlim) {
	if (size == 0)
		return 0;
	uint8* b = (uint8*)malloc(size);
	Z2_STDLIB_GC++;
	if (p)
		memcpy(b, p, rdlim < size ? rdlim : size);
	return b;
}

inline uint8* zl_realloc(void* p, size_t size) {
	uint8* b = (uint8*)realloc(p, size);
	if (b == 0)
		b = (uint8*)p;
	else if (b != p && p == 0)
		Z2_STDLIB_GC++;
	return b;
}

inline void zl_free(void** p) {
	if (*p) {
		Z2_STDLIB_GC--;
		free(*p);
	}
	*p = 0;
}

inline float bitnot(float f) {
	int32* p = (int32*)&f;
	*p = ~*p;
	return *(float*)p;
}

inline double bitnot(double f) {
	int64* p = (int64*)&f;
	*p = ~*p;
	return *(double*)p;
}

template <class T>
class ZArrayDestroyer {
public:
	inline ZArrayDestroyer(T* p, size_t s): ptr(p), size(s) {
	}
	
	inline ~ZArrayDestroyer() {
		for (size_t i = 0 ; i < size; i++)
			ptr[i].~T();
	}
	
private:
	T* ptr;
	size_t size;
};

