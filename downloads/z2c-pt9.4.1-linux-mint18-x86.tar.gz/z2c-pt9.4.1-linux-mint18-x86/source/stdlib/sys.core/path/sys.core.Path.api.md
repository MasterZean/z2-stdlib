# class *Path* from sys.core


## Methods

### GetFolder

```C#
static def GetFolder(path: String): String;
```

#### Brief

#### Parameters
> *path* =>   
#### Returns
> 
***

### GetFolderNoSep

```C#
static def GetFolderNoSep(path: String): String;
```

#### Brief

#### Parameters
> *path* =>   
#### Returns
> 
***

### GetName

```C#
static def GetName(path: String): String;
```

#### Brief

#### Parameters
> *path* =>   
#### Returns
> 
***

### GetNameIndex

```C#
static def GetNameIndex(path: String): PtrSize;
```

#### Brief

#### Parameters
> *path* =>   
#### Returns
> 
***

### GetTitle

```C#
static def GetTitle(path: String): String;
```

#### Brief

#### Parameters
> *path* =>   
#### Returns
> 
***

### GetTitleIndex

```C#
static def GetTitleIndex(path: String): PtrSize;
```

#### Brief

#### Parameters
> *path* =>   
#### Returns
> 
***

### GetExtension

```C#
static def GetExtension(path: String): String;
```

#### Brief

#### Parameters
> *path* =>   
#### Returns
> 
***

### GetExtensionIndex

```C#
static def GetExtensionIndex(path: String): PtrSize;
```

#### Brief

#### Parameters
> *path* =>   
#### Returns
> 
***

### GetParent

```C#
static def GetParent(path: String): String;
```

#### Brief

#### Parameters
> *path* =>   
#### Returns
> 
***

### IsRoot

```C#
static def IsRoot(path: String): Bool;
```

#### Brief

#### Parameters
> *path* =>   
#### Returns
> 
***

## Properties

### CurrentFolder

```C#
property CurrentFolder: String
```

#### Brief

***

### ExeFileName

```C#
property ExeFileName: String; get;
```

#### Brief

***

## Constants

### DirSep

```C#
const DirSep;
```

#### Brief

***

### IgnoreCase

```C#
const IgnoreCase;
```

#### Brief

***

### DirSepWin

```C#
const DirSepWin;
```

#### Brief

***

### DirSepUnix

```C#
const DirSepUnix;
```

#### Brief

***

