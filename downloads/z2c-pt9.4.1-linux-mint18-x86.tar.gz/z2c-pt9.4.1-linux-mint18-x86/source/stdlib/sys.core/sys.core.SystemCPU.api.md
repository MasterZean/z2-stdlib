# class *SystemCPU* from sys.core


## Variables

### Vendor

```C#
val Vendor;
```

#### Brief

***

### MMX

```C#
val MMX;
```

#### Brief

***

### SSE

```C#
val SSE;
```

#### Brief

***

### SSE2

```C#
val SSE2;
```

#### Brief

***

### SSE3

```C#
val SSE3;
```

#### Brief

***

### SSSE3

```C#
val SSSE3;
```

#### Brief

***

### SSE41

```C#
val SSE41;
```

#### Brief

***

### SSE42

```C#
val SSE42;
```

#### Brief

***

### Bits

```C#
val Bits;
```

#### Brief

***

### Cores

```C#
val Cores;
```

#### Brief

***

